package com.example.kylinarm.searchviewdemo.components.view.seach;

import android.view.View;

/**
 * Created by kylin on 2018/2/23.
 */

public interface OnSearchFocusListener {

    void searchFocusChange(View v, boolean hasFocus);

}
