package com.example.kylinarm.searchviewdemo.components.view.seach;

/**
 * Created by kylin on 2018/2/23.
 */

public interface OnSearchListener {
    void search(String content);
}
